#encoding:utf-8

class DefaultConfig:
    learningRate = 0.001                           
    epochs = 100                                   
    test_interval = 5                              
    seg_model_save = './save/'                     
    cls_model_save = './save/'                     
    lr_decay = 0.5                                 
    weight_decay = 1e-5                            
    decay_interval = 50                            
    pin_memory = True                              
    num_testDatasets = 1000                        
    cls_test_path = './data/cls/test'             
    cls_train_path = './data/cls/train'          
    seg_test_path = './data/seg/test'             
    seg_train_path = './data/seg/train'           
    batch_size = 1
    seg_model_path = None
    cls_model_path = None
    eps = 1e-5


class Config(DefaultConfig):
    '''
    在这里修改,覆盖默认值
    '''

opt = Config()