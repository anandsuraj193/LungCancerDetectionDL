import numpy as np

a = np.ones([48,48,48])
#np.save("./2.npy", a)
load1=np.load("./2.npy")
print(load1)